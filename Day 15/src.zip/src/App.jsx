import Navbar from "./components/Navbar";
import "./App.css";

function App() {
  return (
    <>
      <Navbar />

      <main>
        <h1>Welcome to My React App</h1>
        <p>This is my first React navbar.</p>
      </main>
    </>
  );
}

export default App;